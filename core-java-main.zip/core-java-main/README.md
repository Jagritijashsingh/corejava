# Core Java Project
The project implements a programmed solution to compute average assignment rating and work on overall rating for each student and/or subjects to measure effectiveness of learning.
There are multiple subjects and each subject has its own assignment categories - test, lab, project and quiz. Each student can give similar assignment different times. So each time when similar assignment category is entered for a student for a similar subject, the program automatically calculates the assignment number and appends at the end of the name of the category (For eg. test_1, test_2, test_3 and so on).
Whenever a particular assignment category is removed for a student, its particular data is deleted and overall score is updated for that particular student.
The program focuses on core java topics such as LinkedHashMap, LinkedHashSet, Composite Key, Composite Value, List, and etc.
App.java file contains main method. To run the program execute App.java file.
